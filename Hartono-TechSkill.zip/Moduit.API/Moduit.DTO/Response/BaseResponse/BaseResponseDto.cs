﻿namespace Moduit.DTO.Response.BaseResponse
{
    public class BaseResponseDto
    {
        public string ErrorMessage { get; set; } 
    }
}
