﻿namespace Moduit.Constant
{
    public static class ConfigConstant
    {
        public const string JsonName = "appsettings.json";
    }
}