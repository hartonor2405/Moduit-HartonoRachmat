﻿namespace Moduit.Constant
{
    public class QuestionConstant
    {
        public const string Ergonomics = "Ergonomic";
        public const string Sports = "Sports";
    }
}
