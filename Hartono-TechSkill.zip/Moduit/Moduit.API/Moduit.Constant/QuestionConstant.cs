﻿namespace Moduit.Constant
{
    public class QuestionConstant
    {
        public const string Ergonomics = "Ergonomics";
        public const string Sports = "Sports";
    }
}
