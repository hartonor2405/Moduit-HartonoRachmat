﻿using Moduit.DTO.Response.Question;

namespace Moduit.DTO.Response.Question
{
    public class ResQuestionTwoDto : ResQuestionOneDto
    {
        public List<string>? tags { get; set; }
    }
}
