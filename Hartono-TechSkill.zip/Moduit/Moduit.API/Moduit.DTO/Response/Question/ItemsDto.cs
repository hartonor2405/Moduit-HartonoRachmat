﻿namespace Moduit.DTO.Response.Question
{
    public class ItemsDto
    {
        public string title { get; set; }
        public string description { get; set; }
        public string footer { get; set; }
    }
}
